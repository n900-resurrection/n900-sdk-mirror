#ifndef __G_MARSHAL_H__
#define __G_MARSHAL_H__

G_BEGIN_DECLS

/* VOID:VOID (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:26) */
extern void g_cclosure_marshal_VOID__VOID (GClosure     *closure,
                                           GValue       *return_value,
                                           guint         n_param_values,
                                           const GValue *param_values,
                                           gpointer      invocation_hint,
                                           gpointer      marshal_data);

/* VOID:BOOLEAN (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:27) */
extern void g_cclosure_marshal_VOID__BOOLEAN (GClosure     *closure,
                                              GValue       *return_value,
                                              guint         n_param_values,
                                              const GValue *param_values,
                                              gpointer      invocation_hint,
                                              gpointer      marshal_data);

/* VOID:CHAR (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:28) */
extern void g_cclosure_marshal_VOID__CHAR (GClosure     *closure,
                                           GValue       *return_value,
                                           guint         n_param_values,
                                           const GValue *param_values,
                                           gpointer      invocation_hint,
                                           gpointer      marshal_data);

/* VOID:UCHAR (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:29) */
extern void g_cclosure_marshal_VOID__UCHAR (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);

/* VOID:INT (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:30) */
extern void g_cclosure_marshal_VOID__INT (GClosure     *closure,
                                          GValue       *return_value,
                                          guint         n_param_values,
                                          const GValue *param_values,
                                          gpointer      invocation_hint,
                                          gpointer      marshal_data);

/* VOID:UINT (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:31) */
extern void g_cclosure_marshal_VOID__UINT (GClosure     *closure,
                                           GValue       *return_value,
                                           guint         n_param_values,
                                           const GValue *param_values,
                                           gpointer      invocation_hint,
                                           gpointer      marshal_data);

/* VOID:LONG (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:32) */
extern void g_cclosure_marshal_VOID__LONG (GClosure     *closure,
                                           GValue       *return_value,
                                           guint         n_param_values,
                                           const GValue *param_values,
                                           gpointer      invocation_hint,
                                           gpointer      marshal_data);

/* VOID:ULONG (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:33) */
extern void g_cclosure_marshal_VOID__ULONG (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);

/* VOID:ENUM (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:34) */
extern void g_cclosure_marshal_VOID__ENUM (GClosure     *closure,
                                           GValue       *return_value,
                                           guint         n_param_values,
                                           const GValue *param_values,
                                           gpointer      invocation_hint,
                                           gpointer      marshal_data);

/* VOID:FLAGS (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:35) */
extern void g_cclosure_marshal_VOID__FLAGS (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);

/* VOID:FLOAT (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:36) */
extern void g_cclosure_marshal_VOID__FLOAT (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);

/* VOID:DOUBLE (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:37) */
extern void g_cclosure_marshal_VOID__DOUBLE (GClosure     *closure,
                                             GValue       *return_value,
                                             guint         n_param_values,
                                             const GValue *param_values,
                                             gpointer      invocation_hint,
                                             gpointer      marshal_data);

/* VOID:STRING (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:38) */
extern void g_cclosure_marshal_VOID__STRING (GClosure     *closure,
                                             GValue       *return_value,
                                             guint         n_param_values,
                                             const GValue *param_values,
                                             gpointer      invocation_hint,
                                             gpointer      marshal_data);

/* VOID:PARAM (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:39) */
extern void g_cclosure_marshal_VOID__PARAM (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);

/* VOID:BOXED (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:40) */
extern void g_cclosure_marshal_VOID__BOXED (GClosure     *closure,
                                            GValue       *return_value,
                                            guint         n_param_values,
                                            const GValue *param_values,
                                            gpointer      invocation_hint,
                                            gpointer      marshal_data);

/* VOID:POINTER (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:41) */
extern void g_cclosure_marshal_VOID__POINTER (GClosure     *closure,
                                              GValue       *return_value,
                                              guint         n_param_values,
                                              const GValue *param_values,
                                              gpointer      invocation_hint,
                                              gpointer      marshal_data);

/* VOID:OBJECT (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:42) */
extern void g_cclosure_marshal_VOID__OBJECT (GClosure     *closure,
                                             GValue       *return_value,
                                             guint         n_param_values,
                                             const GValue *param_values,
                                             gpointer      invocation_hint,
                                             gpointer      marshal_data);

/* VOID:UINT,POINTER (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:45) */
extern void g_cclosure_marshal_VOID__UINT_POINTER (GClosure     *closure,
                                                   GValue       *return_value,
                                                   guint         n_param_values,
                                                   const GValue *param_values,
                                                   gpointer      invocation_hint,
                                                   gpointer      marshal_data);

/* BOOL:FLAGS (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:46) */
extern void g_cclosure_marshal_BOOLEAN__FLAGS (GClosure     *closure,
                                               GValue       *return_value,
                                               guint         n_param_values,
                                               const GValue *param_values,
                                               gpointer      invocation_hint,
                                               gpointer      marshal_data);
#define g_cclosure_marshal_BOOL__FLAGS	g_cclosure_marshal_BOOLEAN__FLAGS

/* STRING:OBJECT,POINTER (/home/bifh4/fremantle-arm-fremantle1.2.cs2007q3/work/glib2.0-2.20.3/gobject/gmarshal.list:47) */
extern void g_cclosure_marshal_STRING__OBJECT_POINTER (GClosure     *closure,
                                                       GValue       *return_value,
                                                       guint         n_param_values,
                                                       const GValue *param_values,
                                                       gpointer      invocation_hint,
                                                       gpointer      marshal_data);

G_END_DECLS

#endif /* __G_MARSHAL_H__ */
