/* GTK - The GIMP Toolkit
 * Copyright (C) 2000 Red Hat Software
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#if defined(GTK_DISABLE_SINGLE_INCLUDES) && !defined (__GTK_H_INSIDE__) && !defined (GTK_COMPILATION)
#error "Only <gtk/gtk.h> can be included directly."
#endif

#ifndef __GTK_IM_CONTEXT_H__
#define __GTK_IM_CONTEXT_H__

#include <gdk/gdk.h>
#include <gtk/gtkobject.h>
#include <pango/pango.h>

G_BEGIN_DECLS

#ifdef MAEMO_CHANGES
typedef enum
{
  GTK_IM_CONTEXT_CLIPBOARD_OP_COPY,
  GTK_IM_CONTEXT_CLIPBOARD_OP_CUT,
  GTK_IM_CONTEXT_CLIPBOARD_OP_PASTE
} GtkIMContextClipboardOperation;
#endif /* MAEMO_CHANGES */

#define GTK_TYPE_IM_CONTEXT              (gtk_im_context_get_type ())
#define GTK_IM_CONTEXT(obj)              (G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_TYPE_IM_CONTEXT, GtkIMContext))
#define GTK_IM_CONTEXT_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST ((klass), GTK_TYPE_IM_CONTEXT, GtkIMContextClass))
#define GTK_IS_IM_CONTEXT(obj)           (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_TYPE_IM_CONTEXT))
#define GTK_IS_IM_CONTEXT_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_TYPE_IM_CONTEXT))
#define GTK_IM_CONTEXT_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_TYPE_IM_CONTEXT, GtkIMContextClass))


typedef struct _GtkIMContext       GtkIMContext;
typedef struct _GtkIMContextClass  GtkIMContextClass;

struct _GtkIMContext
{
  GObject parent_instance;
};

struct _GtkIMContextClass
{
  /* Yes, this should be GObjectClass, be we can't fix it without breaking
   * binary compatibility - see bug #90935
   */
  GtkObjectClass parent_class;

  /* Signals */
  void     (*preedit_start)        (GtkIMContext *context);
  void     (*preedit_end)          (GtkIMContext *context);
  void     (*preedit_changed)      (GtkIMContext *context);
  void     (*commit)               (GtkIMContext *context, const gchar *str);
  gboolean (*retrieve_surrounding) (GtkIMContext *context);
  gboolean (*delete_surrounding)   (GtkIMContext *context,
				    gint          offset,
				    gint          n_chars);

  /* Virtual functions */
  void     (*set_client_window)   (GtkIMContext   *context,
				   GdkWindow      *window);
  void     (*get_preedit_string)  (GtkIMContext   *context,
				   gchar         **str,
				   PangoAttrList **attrs,
				   gint           *cursor_pos);
  gboolean (*filter_keypress)     (GtkIMContext   *context,
			           GdkEventKey    *event);
  void     (*focus_in)            (GtkIMContext   *context);
  void     (*focus_out)           (GtkIMContext   *context);
  void     (*reset)               (GtkIMContext   *context);
  void     (*set_cursor_location) (GtkIMContext   *context,
				   GdkRectangle   *area);
  void     (*set_use_preedit)     (GtkIMContext   *context,
				   gboolean        use_preedit);
  void     (*set_surrounding)     (GtkIMContext   *context,
				   const gchar    *text,
				   gint            len,
				   gint            cursor_index);
  gboolean (*get_surrounding)     (GtkIMContext   *context,
				   gchar         **text,
				   gint           *cursor_index);

  /* Padding for future expansion */
  void (*_gtk_reserved1) (void);

#ifdef MAEMO_CHANGES
  void     (*show)                (GtkIMContext   *context);
  void     (*hide)                (GtkIMContext   *context);

  /* Signals again: */
  gboolean (*has_selection)       (GtkIMContext   *context);
  void     (*clipboard_operation) (GtkIMContext   *context,
                                   GtkIMContextClipboardOperation operation);

  /* Virtual functions again: */
  gboolean (*filter_event)        (GtkIMContext   *context,
                                   GdkEvent       *event);
#else   /* MAEMO_CHANGES */
  void (*_gtk_reserved2) (void);
  void (*_gtk_reserved3) (void);
  void (*_gtk_reserved4) (void);
  void (*_gtk_reserved5) (void);
  void (*_gtk_reserved6) (void);
#endif /* MAEMO_CHANGES */
};

GType    gtk_im_context_get_type            (void) G_GNUC_CONST;

void     gtk_im_context_set_client_window   (GtkIMContext       *context,
					     GdkWindow          *window);
void     gtk_im_context_get_preedit_string  (GtkIMContext       *context,
					     gchar             **str,
					     PangoAttrList     **attrs,
					     gint               *cursor_pos);
gboolean gtk_im_context_filter_keypress     (GtkIMContext       *context,
					     GdkEventKey        *event);
void     gtk_im_context_focus_in            (GtkIMContext       *context);
void     gtk_im_context_focus_out           (GtkIMContext       *context);
void     gtk_im_context_reset               (GtkIMContext       *context);
void     gtk_im_context_set_cursor_location (GtkIMContext       *context,
					     const GdkRectangle *area);
void     gtk_im_context_set_use_preedit     (GtkIMContext       *context,
					     gboolean            use_preedit);
void     gtk_im_context_set_surrounding     (GtkIMContext       *context,
					     const gchar        *text,
					     gint                len,
					     gint                cursor_index);
gboolean gtk_im_context_get_surrounding     (GtkIMContext       *context,
					     gchar             **text,
					     gint               *cursor_index);
gboolean gtk_im_context_delete_surrounding  (GtkIMContext       *context,
					     gint                offset,
					     gint                n_chars);

#ifdef MAEMO_CHANGES
gboolean hildon_gtk_im_context_filter_event (GtkIMContext   *context,
                                             GdkEvent        *event);

void     gtk_im_context_show                (GtkIMContext   *context);
void     gtk_im_context_hide                (GtkIMContext   *context);

void     hildon_gtk_im_context_show          (GtkIMContext   *context);
void     hildon_gtk_im_context_hide          (GtkIMContext   *context);
gboolean hildon_gtk_im_context_has_selection(GtkIMContext   *context);
void     hildon_gtk_im_context_copy         (GtkIMContext   *context);
void     hildon_gtk_im_context_cut          (GtkIMContext   *context);
void     hildon_gtk_im_context_paste        (GtkIMContext   *context);
#endif /* MAEMO_CHANGES */

G_END_DECLS

#endif /* __GTK_IM_CONTEXT_H__ */
