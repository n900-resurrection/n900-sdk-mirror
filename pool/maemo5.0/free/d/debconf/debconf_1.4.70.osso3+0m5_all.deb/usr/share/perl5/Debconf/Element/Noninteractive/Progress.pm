#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::Element::Noninteractive::Progress;
use strict;
use base qw(Debconf::Element::Noninteractive);


sub start {
}

sub set {
}

sub info {
}

sub stop {
}

1;
