#!/usr/bin/perl -w
# This file was preprocessed, do not edit!


package Debconf::FrontEnd::Noninteractive;
use strict;
use base qw(Debconf::FrontEnd);


1
