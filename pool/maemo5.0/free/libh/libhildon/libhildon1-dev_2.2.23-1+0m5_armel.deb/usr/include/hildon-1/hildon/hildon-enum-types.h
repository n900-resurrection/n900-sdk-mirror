
/* Generated data (by glib-mkenums) */

#ifndef __HILDON_ENUM_TYPES_H__
#define __HILDON_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* Enumerations from "hildon-caption.h" */
GType hildon_caption_status_get_type (void);
#define HILDON_TYPE_CAPTION_STATUS (hildon_caption_status_get_type())
GType hildon_caption_icon_position_get_type (void);
#define HILDON_TYPE_CAPTION_ICON_POSITION (hildon_caption_icon_position_get_type())
/* Enumerations from "hildon-note.h" */
GType hildon_note_type_get_type (void);
#define HILDON_TYPE_NOTE_TYPE (hildon_note_type_get_type())
/* Enumerations from "hildon-number-editor.h" */
GType hildon_number_editor_error_type_get_type (void);
#define HILDON_TYPE_NUMBER_EDITOR_ERROR_TYPE (hildon_number_editor_error_type_get_type())
/* Enumerations from "hildon-time-editor.h" */
GType hildon_date_time_error_get_type (void);
#define HILDON_TYPE_DATE_TIME_ERROR (hildon_date_time_error_get_type())
/* Enumerations from "hildon-time-selector.h" */
GType hildon_time_selector_format_policy_get_type (void);
#define HILDON_TYPE_TIME_SELECTOR_FORMAT_POLICY (hildon_time_selector_format_policy_get_type())
/* Enumerations from "hildon-touch-selector.h" */
GType hildon_touch_selector_selection_mode_get_type (void);
#define HILDON_TYPE_TOUCH_SELECTOR_SELECTION_MODE (hildon_touch_selector_selection_mode_get_type())
/* Enumerations from "hildon-window.h" */
GType hildon_window_clipboard_operation_get_type (void);
#define HILDON_TYPE_WINDOW_CLIPBOARD_OPERATION (hildon_window_clipboard_operation_get_type())
/* Enumerations from "hildon-wizard-dialog.h" */
GType hildon_wizard_dialog_response_get_type (void);
#define HILDON_TYPE_WIZARD_DIALOG_RESPONSE (hildon_wizard_dialog_response_get_type())
/* Enumerations from "hildon-calendar.h" */
GType hildon_calendar_display_options_get_type (void);
#define HILDON_TYPE_CALENDAR_DISPLAY_OPTIONS (hildon_calendar_display_options_get_type())
/* Enumerations from "hildon-pannable-area.h" */
GType hildon_pannable_area_mode_get_type (void);
#define HILDON_TYPE_PANNABLE_AREA_MODE (hildon_pannable_area_mode_get_type())
GType hildon_movement_mode_get_type (void);
#define HILDON_TYPE_MOVEMENT_MODE (hildon_movement_mode_get_type())
GType hildon_movement_direction_get_type (void);
#define HILDON_TYPE_MOVEMENT_DIRECTION (hildon_movement_direction_get_type())
GType hildon_size_request_policy_get_type (void);
#define HILDON_TYPE_SIZE_REQUEST_POLICY (hildon_size_request_policy_get_type())
/* Enumerations from "hildon-button.h" */
GType hildon_button_arrangement_get_type (void);
#define HILDON_TYPE_BUTTON_ARRANGEMENT (hildon_button_arrangement_get_type())
GType hildon_button_style_get_type (void);
#define HILDON_TYPE_BUTTON_STYLE (hildon_button_style_get_type())
/* Enumerations from "hildon-gtk.h" */
GType hildon_portrait_flags_get_type (void);
#define HILDON_TYPE_PORTRAIT_FLAGS (hildon_portrait_flags_get_type())

G_END_DECLS

#endif /* __HILDON_ENUM_TYPES_H__ */

/* Generated data ends here */

